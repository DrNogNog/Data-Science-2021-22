# -*- coding: utf-8 -*-
"""
Created on Mon Apr  5 13:23:09 2021

@author: Gordon Ng
"""

import matplotlib.pyplot as plt
import networkx as nx
import re
import pandas as pd
# A. P. Sarath Chandar	Vikas C. Raykar
# A. Taylan Cemgil	Gaël Richard
# Aadirupa Saha	Shivani Agarwal 0001
# Aaditya Ramdas	Aarti Singh
#two researches that co-authered a paper in one of the top machine learning conferences 2010 and 2016
g = nx.Graph()
# Aaron C. Courville	Simon Lacoste-Julien
# Aaron Roth	Bo Waggoner
# Aarti Singh	Artur Dubrawski
# Aarti Singh	Barnabás Póczos
#two researchers that formed new collaboration in 2017 and 2018

g.add_node(1)
g.add_nodes_from([2,3])
g.add_node('ET')

print(g.nodes(), "nodes")

g.remove_node(1)

print(g.nodes(), "nodes")

g.add_edge(1,2)
g.add_edge(3,'ET')
g.add_edges_from([(2,3), (1,3)])
print(g.edges(), "edges")
print(g.nodes(), "nodes")

g.remove_edge(1,2)
print(g.edges(), "edges")
print(list(g.neighbors(1)), "neighbors")
print(g.degree(1), "degree")

G = nx.DiGraph()
G.add_node(1)
G.add_nodes_from([2,3])
G.add_nodes_from(range(100,110))

H = nx.Graph()
nx.add_path(H, [0,1,2,3,4,5,6,7,8,9])

G.add_nodes_from(H)
print(G.nodes(), "nodes")

nx.draw_networkx(G)
plt.show()

G.add_edge(1, 2)
G.add_edges_from([(1,2),(1,3)])
G.add_edges_from(H.edges())
print(G.edges(), "edges")

nx.draw_networkx(G)
plt.show()

G = nx.lollipop_graph(4, 6)
nx.draw_networkx(G)
plt.show()

print("diameter: %d" % nx.diameter(G))
print()
print("degree centrality of nodes in G: ", nx.degree_centrality(G))