# -*- coding: utf-8 -*-
"""
Created on Mon Apr  5 15:10:04 2021

@author: Gordon Ng
"""
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import math
# A. P. Sarath Chandar	Vikas C. Raykar
# A. Taylan Cemgil	Gaël Richard
# Aadirupa Saha	Shivani Agarwal 0001
# Aaditya Ramdas	Aarti Singh
#two researches that co-authered a paper in one of the top machine learning conferences 2010 and 2016

# Aaron C. Courville	Simon Lacoste-Julien
# Aaron Roth	Bo Waggoner
# Aarti Singh	Artur Dubrawski
# Aarti Singh	Barnabás Póczos
#two researchers that formed new collaboration in 2017 and 2018

def read_file(file):
    df = pd.read_csv(file, delimiter = "\t",names=['Name','Collab'])
    df = df[['Name','Collab']]
    #assign column names
    G = nx.Graph()
    G = nx.from_pandas_edgelist(df, 'Name','Collab')
    #create a nx graph with both columns
    figure(figsize=(10,8))
    nx.draw_shell(G, with_labels=True)
    plt.show()
    return df
#twoold = read_file('old_edges.txt')
#twonew = read_file('new_edges.txt')

readfunction = open("old_edges.txt", 'r', encoding="utf8")
Gold = nx.read_edgelist(readfunction, delimiter = '\t')
print(nx.info(Gold))
print(Gold.degree(), "Degree of Old Collaborations")

readfunction2 = open("new_edges.txt", 'r', encoding="utf8")
Gnew = nx.read_edgelist(readfunction2, delimiter = '\t')
print(nx.info(Gnew))
print(Gnew.degree(), "Degree of New Collaborations")

#For the next tasks, firstten (and shortlistend new collaborations for) those
#authors that formed at least 10 new connections between 2017-2018.
"""-------------------------------HELPER FUNCTIONS FOR COMPARISON:------------------------------"""
def mOtherFriends(G, X):
    "Who's My Friends?"
    return set(G.neighbors(X))
def friends_of_friends(G, X):
    "A Friend of A Friend Connection"
    GMyFriends = mOtherFriends(G, X)
    GNetworkFoF = set()
    for friend in GMyFriends:
        GNetworkFoF.update(mOtherFriends(G, friend) - GMyFriends)
    return GNetworkFoF - {X}
def common_friends(G, X1, X2):
    "Common X1 and X2."
    return mOtherFriends(G, X1).intersection(mOtherFriends(G, X2))
"""c) -------------------------------BREAKER------------------------------"""
def common_friends_number(G, X):
    common_friends_dict = {}
    GNetworkFoF = friends_of_friends(G, X)
    for x in GNetworkFoF:
        number = len(common_friends(G, X, x))
        if number >= 1:
            common_friends_dict[x] = number
    listoflist = [i[0] for i in sorted(common_friends_dict.items(), reverse=True, key=lambda kv: kv[1])]
    return listoflist
"""d)-------------------------------BREAKER------------------------------"""
def jaccard_index(G, X):
    "Jaccard's Index Reccommendations"
    dictionary = {}
    GMyFriends = mOtherFriends(G, X)
    GNetworkFoF = friends_of_friends(G, X)
    for x in GNetworkFoF:
        OtherFriends = mOtherFriends(G, x)
        intersect = len(common_friends(G, X, x))
        union = (len(GMyFriends) + len(OtherFriends)) - intersect
        JScore = intersect / union
        dictionary[x] = JScore
    listoflist = [i[0] for i in sorted(dictionary.items(), reverse=True, key=lambda kv: kv[1])]
    return listoflist
"""e)-------------------------------BREAKER------------------------------"""
def adamic_adar_index(G, X):
    "Adamic/Adar Index Reccommendations"
    dictionary = {}
    GNetworkFoF = friends_of_friends(G, X)
    for x in GNetworkFoF:
        OurCommons = common_friends(G, X, x)
        AScore = 0
        for Z in OurCommons:
            Z_friends = mOtherFriends(G, Z)
            AScore += 1 / math.log(len(Z_friends))
        dictionary[x] = AScore
    listoflist = [i[0] for i in sorted(dictionary.items(), reverse=True, key=lambda kv: kv[1])]
    return listoflist
"""f)-------------------------------BREAKER------------------------------"""
# Common Friends
firstten = [node for node,degree in dict(Gnew.degree()).items() if degree >= 10]
accuracy_dict = {}
for X in firstten:
    # take the 10 first shortlistendations for each user
    shortlist = common_friends_number(Gold, X)[0:10]
    FriendConnection = mOtherFriends(Gnew, X)
    # calculate the number of them that were actually formed during 2017-2018
    found_in_true_friends = set(shortlist).intersection(FriendConnection)
    accuracy_dict[X] = len(found_in_true_friends) / len(FriendConnection)
# calculate the average among users
score = [i for _, i in accuracy_dict.items()]
average = sum(score) / len(score)
print(average)
"""------------------------------------------------"""
# Jaccard Index
accuracy_dict = {}
for X in firstten:
    shortlist = jaccard_index(Gold, X)[0:10]
    FriendConnection = mOtherFriends(Gnew, X)  
    found_in_true_friends = set(shortlist).intersection(FriendConnection)
    accuracy_dict[X] = len(found_in_true_friends) / len(FriendConnection)
score = [i for _, i in accuracy_dict.items()]
average = sum(score) / len(score)
print(average)
"""------------------------------------------------"""
# Adamic/Adar Index
accuracy_dict = {}
for X in firstten:
    shortlist = adamic_adar_index(Gold, X)[0:10]
    FriendConnection = mOtherFriends(Gnew, X)
    found_in_true_friends = set(shortlist).intersection(FriendConnection)
    accuracy_dict[X] = len(found_in_true_friends) / len(FriendConnection)
score = [i for _, i in accuracy_dict.items()]
average = sum(score) / len(score)
print(average)
"""------------------------------------------------"""
# Common Friends Part 2
rankdictionary = {}
for X in firstten:
    shortlist = common_friends_number(Gold, X)
    FriendConnection = mOtherFriends(Gnew, X) 
    for person in FriendConnection:
        if person in shortlist:
            rank = shortlist.index(person)
        else:
            rank = len(shortlist)
        rankdictionary[person] = rank
values = [i for _, i in rankdictionary.items()]
average = sum(values) / len(values)
print(average)
"""------------------------------------------------"""
# Jaccard Index Part 2
rankdictionary = {}
for X in firstten:
    shortlist = jaccard_index(Gold, X)
    FriendConnection = mOtherFriends(Gnew, X) 
    for person in FriendConnection:
        if person in shortlist:
            rank = shortlist.index(person)
        else:
            rank = len(shortlist)
        rankdictionary[person] = rank
values = [i for _, i in rankdictionary.items()]
average = sum(values) / len(values)
print(average)
"""------------------------------------------------"""
# Adamic/Adar Index Part 2
rankdictionary = {}
for X in firstten:
    shortlist = adamic_adar_index(Gold, X)
    FriendConnection = mOtherFriends(Gnew, X)
    for person in FriendConnection:
        if person in shortlist:
            rank = shortlist.index(person)
        else:
            rank = len(shortlist)
        rankdictionary[person] = rank
values = [i for _, i in rankdictionary.items()]
average = sum(values) / len(values)
print(average)