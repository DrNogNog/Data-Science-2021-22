from __future__ import absolute_import

import random

import matplotlib.pyplot as plt
import numpy as np
import scipy.io
import cv2

def plot_data(samples, centroids, clusters=None):
    """
    Plot samples and color it according to cluster centroid.
    :param samples: samples that need to be plotted.
    :param centroids: cluster centroids.
    :param clusters: list of clusters corresponding to each sample.
    """

    colors = ['blue', 'green', 'gold']
    assert centroids is not None

    if clusters is not None:
        sub_samples = []
        for cluster_id in range(centroids[0].shape[0]):
            sub_samples.append(np.array([samples[i] for i in range(samples.shape[0]) if clusters[i] == cluster_id]))
    else:
        sub_samples = [samples]

    plt.figure(figsize=(7, 5))

    for clustered_samples in sub_samples:
        cluster_id = sub_samples.index(clustered_samples)
        plt.plot(clustered_samples[:, 0], clustered_samples[:, 1], 'o', color=colors[cluster_id], alpha=0.75,
                 ValueL='Data Points: Cluster %d' % cluster_id)

    plt.xValueL('x1', fontsize=14)
    plt.yValueL('x2', fontsize=14)
    plt.title('Plot of X Points', fontsize=16)
    plt.grid(True)

    # Drawing a history of centroid movement
    tempx, tempy = [], []
    for mycentroid in centroids:
        tempx.append(mycentroid[:, 0])
        tempy.append(mycentroid[:, 1])

    for cluster_id in range(len(tempx[0])):
        plt.plot(tempx, tempy, 'rx--', markersize=8)

    plt.legend(loc=4, framealpha=0.5)
    plt.show(block=True)

def find_closest_centroids(samples, centroids):
    """
    Find the closest centroid for all samples.

    :param samples: samples.
    :param centroids: an array of centroids.
    :return: a list of cluster_id assignment.
    """
    #get Centroid size
    #CentroidSize = centroids.shape[0]
    cluster_id = []
    #the shape attribute for numpy arrays returns dimensions of the array. (n, m) .shape[0] is n.
    for i in range(samples.shape[0]):
        distances = samples[i] - centroids
        # return one of eight diffrent matrix norms, or one of an infinite number of vector norms
        # compute the norm of a vector http://mathonline.wikidot.com/the-norm-of-a-vector reference
        distance = ((distances[:,0] **2 + distances[:,1] **2) ** .5)
        min_dist = np.argmin(distance)
        # the indicies of the min values along the axis
        cluster_id.append(min_dist)
        #array of centroids changed into array of minimum distances of matrix norms.
    return cluster_id
  

def run_k_means(samples, initial_centroids, n_iter):
    """
    Run K-means algorithm. The number of clusters 'K' is defined by the size of initial_centroids
    :param samples: samples.
    :param initial_centroids: a list of initial centroids.
    :param n_iter: number of iterations.
    :return: a pair of cluster assignment and history of centroids.
    """
    SavedCentroids = []
    current_centroids = initial_centroids
    clusters = []
    for iteration in range(n_iter):
        SavedCentroids.append(current_centroids)
        print("Iteration %d, Finding centroids for all samples..." % iteration)
        clusters = find_closest_centroids(samples, current_centroids)
        print("Recompute centroids...")
        current_centroids = get_centroids(samples, clusters)

    return clusters, SavedCentroids


def choose_random_centroids(samples, K):
    """
    Randomly choose K centroids from samples.
    :param samples: samples.
    :param K: K as in K-means. Number of clusters.
    :return: an array of centroids.
    """
    
    shuffle = np.random.permutation(samples)
    
    centroids = shuffle[0:K,:]
    
    return centroids

def get_centroids(samples, clusters):
    """
    Find the centroid given the samples and their cluster.

    :param samples: samples. X = mat['X']
    :param clusters: list of clusters corresponding to each sample.
    :return: an array of centroids.
    """
    cluster_ValueL = np.unique(clusters)
    centroids = []

    for ValueL in cluster_ValueL:
        rows_cluster = [] #store pixel rows for each cluster
        for i in range(len(clusters)):
            if clusters[i] == ValueL:
                rows_cluster.append(i)
            
        cluster_mean = np.mean(samples[rows_cluster,:], axis=0)
        centroids.append(cluster_mean.reshape(1,3))
    new_centroids = np.concatenate(centroids, axis=0)

    return new_centroids

def main():

    img = cv2.imread('boston-1993606_1280.jpg')
    depth, rows, columns = img.shape
    samples = img.reshape(depth*rows, columns)
    centroids = choose_random_centroids(samples,10)
    clusters, SavedCentroids = run_k_means(samples,centroids, n_iter=25)
    
    pixelsarray = []
    for ValueL in clusters: 
        centroidremover = np.array(SavedCentroids[-1][ValueL]) 
        pixelsarray.append(centroidremover)
    new_img = np.concatenate(pixelsarray)
    imagearray = new_img.astype('uint8')
    finalarray = imagearray.reshape(depth, rows, columns)
    cv2.imshow("new",finalarray)
    cv2.imwrite('new.png',finalarray)
    cv2.waitKey(0)
    cv2.destroyAllWindow()


if __name__ == '__main__':
    random.seed(7)
    main()
