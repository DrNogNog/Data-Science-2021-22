# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 13:51:55 2021

@author: Gordon Ng
gng8@bu.edu

"""
import math
import numpy as np

def import_data(filename):
    X = [] #2d array
    temporary = []
    y = [] #1d array
    with open(filename) as file:
        for line in file:
            singlelineinloop = line.split(',')
            if '?' in singlelineinloop:
                singlelineinloop[singlelineinloop.index('?')] = 'NaN'
            temporary.append(singlelineinloop[279])
            X.append(singlelineinloop[0:278])
    for element in temporary:
        y.append(element.strip())
    file.close()
    return X,y

def transpose(x):
    t_list = list(map(list,zip(*x)))
    return t_list

def median(x):
    n = len(x)
    s = sorted(x)
    return (sum(s[n//2-1:n//2+1])/2.0,s[n//2])[n%2] if n else None

def Remove_NaN(l):
    jeopardy = [[]] * len(l)
    for i in range(len(l)):
        jeopardy[i] = [x for x in l[i] if math.isnan(x) == False]
    return jeopardy

def Replace_NaN(l,value):
    jeopardy = []
    for i in range(len(l)):
        if math.isnan(l[i]):
            jeopardy.append(value)
        else:
            jeopardy.append(l[i])

    return jeopardy

def impute_missing(X):
    trans_x = transpose(X)
    jeopardy = [[]] * len(trans_x)
    cleaned_trans_x = Remove_NaN(trans_x)
    medianListi = []
    for feature in cleaned_trans_x:
        medianListi.append(median(feature))
    index = 0
    for x in trans_x:
        jeopardy[index] = Replace_NaN(x,medianListi[index]) 
        index += 1     
    return transpose(jeopardy)


# SHORT RESPONSE
#  [1pt.] Explain why sometimes it is better to use the median instead
#  of the mean of an attribute for missing values.
#
# Sometimes it is better to use the median value because if you have a
# major outlier, the mean would not fit your data. If you had [1, 1, 1...]
# and then at the end of the list you had ten trillion, the mean would not
# represent your data very well, whereas the median would.


def shuffle_data(X, y):
    listxo = np.array(range(len(X)))
    np.random.shuffle(listxo)
    ArrayOne = []
    ArrayTwo = []
    for x in listxo:
        ArrayOne.append(X[x])
        ArrayTwo.append(y[x])
    return ArrayOne, ArrayTwo



def std_row(row):
    mean_sum = sum(row) / len(row)
    std = (sum( (x-mean_sum) ** 2.0 for x in row ) / float(len(row)) ) ** 0.5
    return std

def compute_std(X):
    lst = []
    X = transpose(X)
    for l in X:
        lst.append(std_row(l))
    return lst

def mean(l):
    mean = sum(l)/len(l)
    return mean

def remove_outlier( X, y):
    X = transpose(X)
    keepers = []
    fresh = [] * len(X)
    mathing = [] * len(X)
    variablea = []
    mathingy = []
    for feature in X:
        feature_mean = mean(feature)
        feature_std = std_row(feature)
        parsing1 = abs(feature_mean + (2* feature_std))
        parsing2 = abs(feature_mean - (2* feature_std))
        
        for value in feature: 
            if abs(value) > abs(parsing1) or abs(value) < abs(parsing2):
                mathing.append(feature)
            else:
                keepers.append(feature)
        fresh.append(keepers)
        keepers = []

    for value in y:
        y_mean = mean(y)
        std_y = std_row(y)
        high = y_mean + 2 * std_y
        low = y_mean - 2* std_y
        if abs(value) > abs(high) or abs(value) < abs(low):
            mathingy.append(value)
        else:
            variablea.append(value)
    
    return transpose(fresh) ,variablea

def standard(l):
    m = sum(l)/len(l)
    std = std_row(l)
    lstofnewvariable = [] * len(l)
    for value in l:
        if value == float(0):
            lstofnewvariable.append(value)
        else:
            lstofnewvariable.append((value - m) // std)
    return lstofnewvariable 



def standardize_data(X):
    X = transpose(X)
    fresh = [] * len(X)
    for l in X:
        fresh.append(standard(l))
    return transpose(fresh)

# SHORT RESPONSE
# The BigO notation of this function should be O(n) because it only runs through the n variable once with a for loop.


####TEST FUNCTIONS####
#X,y = import_data('test.data')

#NumpyView = np.array(X)
#print(NumpyView)
#ald = [10, 20, 30, 50, 60, 70, 80, 90, 100,10,10]
#ald.remove(10)
#print(ald)

#impute_missing(X)

#### Continuous Breaker ####
def convert(l):
    listingofconvert = []
    for element in l:
        if element == 'female':
            listingofconvert.append(int(0))
        elif element == 'male':
            listingofconvert.append(int(1))
        elif element == 'Q':
            listingofconvert.append(int(1))
        elif element == 'C':
            listingofconvert.append(int(0))
        elif element == 'S':
            listingofconvert.append(int(2))
        elif element == "":
                element = float('NaN')
        else:
            listingofconvert.append(float(element))
    return listingofconvert


def data_read_and_write(file):
    file = open(file, 'r')
    X = []
    y = []
    data = file.readlines()
    for line in data[1:]:
        temporary = []
        q1 = line.find('"')
        q2 = line.rfind('"')
        rowwww = line[0:q1].strip(',').split(',')
        theotherrowwww = line[q2+1:].strip(',').split(',')
        temporary.append(rowwww[0])
        temporary.append(rowwww[2])
        temporary.append(theotherrowwww[0])
        temporary.append(theotherrowwww[1])
        temporary.append(theotherrowwww[2])
        temporary.append(theotherrowwww[3])
        temporary.append(theotherrowwww[5])
        temporary.append(theotherrowwww[7].strip('\n'))
        y.append(rowwww[1])
        X.append(temporary)
        fresh = []
    for l in X:
        fresh.append(convert(l))
    import probability; probability.set_trace()
    
    return fresh , y

def train_test_split(X, y, t_f):
    X = np.array(X)
    y = np.array(y)
    firstsplit = np.split(X,[int(t_f * len(X))]) 
    split_y = np.split(y,[int(t_f * len(y))]) 
    firstsplit,split_y = shuffle_data(firstsplit,split_y)
    firsttrain = firstsplit[1]
    firsttest = firstsplit[0]
    secondtrain = split_y[1]
    firsttesty = split_y[0]
    
    return firsttrain, secondtrain, firsttest, firsttesty


def train_test_CV_split(X,y, t_f, cv_f):
    X = np.array(X)
    y = np.array(y)

    firstsplit = np.split(X,[int(t_f * len(X))]) 
    split_y = np.split(y,[int(t_f * len(y))]) 
    firstsplit,split_y = shuffle_data(firstsplit,split_y)
    firsttest = firstsplit[0] 
    valid = np.split(firstsplit[1],[int(cv_f * len(firstsplit[1]))])
    completex = valid[1]
    firsttrain = valid[0]
    firsttesty = split_y[0] 
    firstcompletey = np.split(split_y[1],[int(cv_f * len(split_y[1]))])
    completey = firstcompletey[1]
    secondtrain = firstcompletey[0]

    return firsttrain, secondtrain, firsttest, firsttesty, completex, completey



