# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 03:58:40 2021

@author: Gordon Ng
"""

import random
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

mnist_data = np.load('mnist_data.npy')
mnist_labels = np.load('mnist_labels.npy')

def twob(mnist_data,mnist_labels):
    data_train, data_test, labels_train, labels_test = train_test_split(mnist_data, mnist_labels, test_size=0.20, random_state=32)
    
    model = LogisticRegression(multi_class='multinomial', random_state=0).fit(data_train, labels_train)
    predictions = model.predict(data_test)
    print(accuracy_score(labels_train, model.predict(data_train)), "Train Accuracy")
    print(accuracy_score(labels_test, predictions), "Test Accuracy")
    #0.9611904761904762 Train Accuracy
    #0.9142857142857143 Test Accuracy
twob(mnist_data,mnist_labels)

def twocd(mnist_data,mnist_labels):
    data_train, data_test, labels_train, labels_test = train_test_split(mnist_data, mnist_labels, test_size=0.20, random_state=32)
    scaler = StandardScaler()
    scaler.fit(data_train)
    X_train = scaler.transform(data_train)
    #X_test = scaler.transform(data_test)
    array = [KNeighborsClassifier(n_neighbors=k) for k in range(26) if k%2==1]
    array2 = [i.fit(X_train, labels_train) for i in array]
    #trained model ^
    array3 = [accuracy_score(labels_train,i.predict(X_train)) for i in array2]
    #train accuracy ^
    array4 = [accuracy_score(labels_test,i.predict(data_test)) for i in array2]
    print(array3, "Train Accuracy")
    print(array4, "Test Accuracy")
    arrayx = [k for k in range(26) if k%2==1]
    plt.plot(arrayx, array3, 'r--',arrayx, array4, 'g^')
    plt.show()
    #[1.0000000000000000, 0.9631547619047619, 0.9505357142857143, 0.9416666666666667, 0.9364880952380953, 0.9335119047619047, 0.9283928571428571, 0.9240476190476190, 0.9208928571428572, 0.9193452380952380, 0.9172619047619047, 0.9150595238095238, 0.9118452380952381] Train Accuracy
    #[0.7154761904761905, 0.7561904761904762, 0.7966666666666666, 0.8219047619047619, 0.8369047619047619, 0.8409523809523810, 0.8476190476190476, 0.8466666666666667, 0.8471428571428572, 0.8464285714285714, 0.8426190476190476, 0.8426190476190476, 0.8419047619047619] Test Accuracy
    # My Train Accuracy shows me that my KNN accuracy on the train set decreases as KNN classifiers increase in neighbors.
    # My Test Accuracy shows me that my KNN accuracy on the test set increases as KNN classifiers increase in neighbors.
    # A small value of K means that noise will have a higher influence on the result.
    # My model for the train accuracy generalizes and has a negative effect on accuracy.
    # My model for the test accuracy generalizes and has a positive effect of accuracy.
twocd(mnist_data,mnist_labels)
def twoe(mnist_data,mnist_labels):
    data_train, data_test, labels_train, labels_test = train_test_split(mnist_data, mnist_labels, test_size=0.20, random_state=32)
    data_train3000 = data_train[:3000]
    data_train6000 = data_train[:6000]
    data_train9000 = data_train[:9000]
    data_train12000 = data_train[:12000]
    data_train15000 = data_train[:15000]
    data_train16800 = data_train
    
    labels_train3000 = labels_train[:3000]
    labels_train6000 = labels_train[:6000]
    labels_train9000 = labels_train[:9000]
    labels_train12000 = labels_train[:12000]
    labels_train15000 = labels_train[:15000]
    labels_train16800 = labels_train
    
    model = KNeighborsClassifier(n_neighbors=2)
    # data_training = [data_train3000, data_train6000, data_train9000, data_train12000, data_train15000, data_train16800]
    # labels_training = [labels_train3000,labels_train6000,labels_train9000,labels_train12000,labels_train15000,labels_train16800]
    model_fit = model.fit(data_train3000, labels_train3000)
    model_fit1 = model.fit(data_train6000, labels_train6000)
    model_fit2 = model.fit(data_train9000, labels_train9000)
    model_fit3 = model.fit(data_train12000, labels_train12000)
    model_fit4 = model.fit(data_train15000, labels_train15000)
    model_fit5 = model.fit(data_train16800, labels_train16800)
    
    zero = accuracy_score(labels_train3000,model_fit.predict(data_train3000))
    one = accuracy_score(labels_train6000,model_fit1.predict(data_train6000))
    two = accuracy_score(labels_train9000,model_fit2.predict(data_train9000))
    three = accuracy_score(labels_train12000,model_fit3.predict(data_train12000))
    four = accuracy_score(labels_train15000,model_fit4.predict(data_train15000))
    five = accuracy_score(labels_train16800,model_fit5.predict(data_train16800))
    print(zero,one,two,three,four,five)
    #0.9763333333333334 0.9788333333333333 0.9801111111111112 0.9809166666666667 0.9812 0.9813690476190476
    arrayx = [3000,6000,9000,12000,15000,16800]
    arrayy = [zero,one,two,three,four,five]
    plt.plot(arrayx, arrayy, 'r--')
    plt.show()
    #     KNN-
    # Pros:   Not Parametric, 
    # 	no assumptions to be madem no training step, 
    # 	Classification and Regression as well as multi-class problems, 
    # 	variety of distance criteria to be chosen from
    # Cons:   KNN slow as more dataset grows
    # 	KNN needs homogeneous features,
    # 	imbalanced data causes problems,
    # 	missing values are wrong,
    # 	finding optimal number of neighbors needs visualization
    # Logistic Regression-
    # Pros:	makes no assumptions about distributions of classes,
    # 	extend to multinomial regression,
    # 	fast at missing datas,
    # 	model coefficients and intercepts,
    # 	less inclined to over-fitting
    # Cons:	linear boundaries,
    # 	average or no multicollinearity between independent variables
    # 	non-linear problems cant be solved
    # 	if observations is less than number of features, Logistic Regression shouldn't be used
    # Linear Regression-
    # Pros:	easy to implement
    # 	less complexity
    # Cons:	outliers cause erros
    # 	can over-fit easily
    # 	mean is not a complete description of a variable, so its not as accurate.
    # Logistic Regression is better when dealing with outliers due to it doing comparisions with least squares.
twoe(mnist_data,mnist_labels)