# -*- coding: utf-8 -*-
"""
Created on Mon Mar 22 03:18:54 2021

@author: Gordon Ng
"""
import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression

def y(x, m, b):
     return m*x + b
 

def data_without_outlier():
    plt.ylim([-8, 4])
    plt.xlim([-4, 9])
    X = np.linspace(-4, 4, 50)
    y_above = [y(x, 1, 0) + abs(random.gauss(2,1)) for x in X]
    y_below = [y(x, 1, 0) - abs(random.gauss(2,1)) for x in X] #gauss((mean,standard_deviation))
    plt.scatter(X, y_below, c='b')
    plt.scatter(X, y_above, c='r')
    plt.plot(X, X + 0, linestyle='solid', c='g')
    plt.show()
    
def data_with_outlier():
    plt.ylim([-8, 4])
    plt.xlim([-4, 9])
    X = np.linspace(-4, 4, 50)
    y_above = [y(x, 1, 0) + abs(random.gauss(2,1)) for x in X]
    y_below = [y(x, 1, 0) - abs(random.gauss(2,1)) for x in X] #gauss((mean,standard_deviation))
    plt.scatter(X, y_below, marker = 'o', facecolors='none', edgecolors='b')
    plt.scatter(X, y_above, marker = 'X', c = 'r', linewidth=.005, s=100)
    plt.plot(X, X + 0, linestyle='solid', c='g')
    outlier = np.linspace(6.9,8.5, 10)
    outlier_line = [y(x, .8, -11.2) + abs(random.gauss(2,1)) for x in outlier]
    plt.scatter(outlier, outlier_line, marker = 'o', facecolors='none', edgecolors='b')
    plt.savefig('plot.png', dpi=300, bbox_inches='tight')
    plt.show()
    
def data_without_outlier_least_squares_andlog():
    plt.ylim([-8, 4])
    plt.xlim([-4, 9])
    X = np.linspace(-4, 4, 50)
    #############################
    newX = np.tile(X, 2)
    newX = np.array([[i] for i in newX])

    n = newX.shape[1]
    r = np.linalg.matrix_rank(newX)
    ###############################
    y_above = [y(x, 1, 0) + abs(random.gauss(2,1)) for x in X]
    y_below = [y(x, 1, 0) - abs(random.gauss(2,1)) for x in X] #gauss((mean,standard_deviation))
    ###############################
    newY = np.concatenate((y_above, y_below))
    newY = np.array([[i] for i in newY])
    U, sigma, VT = np.linalg.svd(newX, full_matrices=False)
    D_plus = np.diag(np.hstack([1/sigma[:r], np.zeros(n-r)]))
    V = VT.T
    X_plus = V.dot(D_plus).dot(U.T)
    w = X_plus.dot(newY)
    
    savedX = (np.ravel(newX))
    savedY = (np.ravel(newY))
    PX = np.vstack((savedX, savedY)).T
    PX.astype('int')
    one = np.ones(50)
    zero = np.zeros(50)
    ynew = np.concatenate((one,zero))

    clf = LogisticRegression(solver='liblinear', random_state=0).fit(PX, ynew)
    w0 = clf.intercept_[0]
    w1 = clf.coef_[0,0]
    w2 = clf.coef_[0,1]
    
    xp = np.linspace(-4,9,100).reshape(-1,1)
    yp = - w1/w2*xp - w0/w2
    plt.plot(xp, yp, 'purple', linewidth = 1, label = 'Logistic Regression')

    plt.scatter(X, y_below, c='b')
    plt.scatter(X, y_above, c='r')
    plt.plot(newX, w*newX, c='red')
    plt.show()
    
def data_with_outlier_least_squares_andlog():
    plt.ylim([-8, 4])
    plt.xlim([-4, 9])
    X = np.linspace(-4, 4, 50)
    outlier = np.linspace(6.9,8.5, 10)
    #####################
    newX = np.tile(X, 2)
    newX = np.concatenate((newX, outlier))
    newX = np.array([[i] for i in newX])
    n = newX.shape[1]
    r = np.linalg.matrix_rank(newX)
    ###################### 
    y_above = [y(x, 1, 0) + abs(random.gauss(2,1)) for x in X]
    y_below = [y(x, 1, 0) - abs(random.gauss(2,1)) for x in X] #gauss((mean,standard_deviation))
    outlier_line = [y(x, .8, -11.2) + abs(random.gauss(2,1)) for x in outlier]
    #################### Linear
    newY = np.concatenate((y_above, y_below))
    newY = np.concatenate((newY, outlier_line))
    newY = np.array([[i] for i in newY])
    U, sigma, VT = np.linalg.svd(newX, full_matrices=False)
    D_plus = np.diag(np.hstack([1/sigma[:r], np.zeros(n-r)]))
    V = VT.T
    X_plus = V.dot(D_plus).dot(U.T)
    w = X_plus.dot(newY)
    ##########################
    listed = np.array([[i] for i in outlier])
    listed2 = np.array([[i] for i in outlier_line])
    savedX = np.concatenate((newX, listed))
    savedY = np.concatenate((newY, listed2))
    savedX = (np.ravel(newX))
    savedY = (np.ravel(newY))
    PX = np.vstack((savedX, savedY)).T
    PX.astype('int')
    one = np.ones(50)
    zero = np.zeros(60)
    ynew = np.concatenate((one,zero))
    
    clf = LogisticRegression(solver='liblinear', random_state=0).fit(PX, ynew)
    w0 = clf.intercept_[0]
    w1 = clf.coef_[0,0]
    w2 = clf.coef_[0,1]
    
    xp = np.linspace(-4,9,100).reshape(-1,1)
    yp = - w1/w2*xp - w0/w2
    plt.plot(xp, yp, 'purple', linewidth = 1, label = 'Logistic Regression')
    # error = np.linalg.norm(newX.dot(w) - newY, ord=2) ** 2
    # print(error)
    ##################### Plots
    plt.scatter(X, y_below, marker = 'o', facecolors='none', edgecolors='b')
    plt.scatter(X, y_above, marker = 'X', c = 'r', linewidth=.005, s=100)
    plt.scatter(outlier, outlier_line, marker = 'o', facecolors='none', edgecolors='b')
    plt.plot(newX, w*newX, c='blue')
    plt.savefig('plot.png', dpi=300, bbox_inches='tight')
    plt.show()
    
#data_without_outlier_least_squares_andlog()
data_with_outlier_least_squares_andlog()
# m = 100
# X = np.hstack([np.ones([m,1]), 4*np.random.rand(m,1), 4*np.random.rand(m,1)])
# X = np.asmatrix(X)
# X = X[:,1:3]
# y = np.empty([m,1])
# C1 = np.where(y == True)[0]
# C0 = np.where(y == False)[0]
# y[C1] = 1
# y[C0] = -1
# y = np.asmatrix(y)

# print(y)
# def test():
#     X, y, coefficients = make_regression(
#         n_samples=50,
#         n_features=1,
#         n_informative=1,
#         n_targets=1,
#         noise=5,
#         coef=True,
#         random_state=1
#     )
#     n = X.shape[1]
#     r = np.linalg.matrix_rank(X)
#     #print(X)
#     U, sigma, VT = np.linalg.svd(X, full_matrices=False)
#     D_plus = np.diag(np.hstack([1/sigma[:r], np.zeros(n-r)]))
#     V = VT.T
#     X_plus = V.dot(D_plus).dot(U.T)
#     w = X_plus.dot(y)
#     print(X_plus)
#     print(w)
# #test()