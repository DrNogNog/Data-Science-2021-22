# -*- coding: utf-8 -*-
"""
Created on Wed Mar 24 18:46:07 2021

@author: Gordon Ng
"""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.decomposition import IncrementalPCA
import pandas as pd
import scipy
import timeit

mnist_data = np.load('mnist_data.npy')
mnist_labels = np.load('mnist_labels.npy')

data_train, data_test, labels_train, labels_test = train_test_split(mnist_data, mnist_labels, test_size=0.20, random_state=32)
# data_train = StandardScaler().fit_transform(data_train)
# data_test = StandardScaler().fit_transform(data_test)
def threeABC(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test):
    n = 90
    pca = PCA(n_components=n)
    principalComponents = pca.fit_transform(data_train)
    principalComponents2 = pca.fit_transform(data_test)
    #principalDf = pd.DataFrame(data = principalComponents)
    array = [x+1 for x in range(90)]
    #print(array)
    print(sum(pca.explained_variance_ratio_))
    norm_cdf = scipy.stats.norm.cdf(pca.explained_variance_ratio_)
    #print(norm_cdf)
    plt.plot(array, norm_cdf, 'r--')
    plt.show()
    # I chose 90 because when we sum the information of explained variance ratio, we get around 90% of the information, which is good enough for me.
    # This number is less than the original eigen value vectors of greater than 700.
    model = KNeighborsClassifier(n_neighbors=2)
    model1 = model.fit(principalComponents, labels_train)
    print(accuracy_score(labels_train,model1.predict(principalComponents)), "Train Accuracy")
    model2 = model.fit(principalComponents2, labels_test)
    print(accuracy_score(labels_test,model2.predict(principalComponents2)), "Test Accuracy")
    # 0.9838690476190476 Train Accuracy
    # 0.9728571428571429 Test Accuracy
#threeABC(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test)
def threeD(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test):
    data_train, data_test, labels_train, labels_test = train_test_split(mnist_data, mnist_labels, test_size=0.20, random_state=32)
    data_train3000 = data_train[:3000]
    data_train6000 = data_train[:6000]
    data_train9000 = data_train[:9000]
    data_train12000 = data_train[:12000]
    data_train15000 = data_train[:15000]
    data_train16800 = data_train
    
    labels_train3000 = labels_train[:3000]
    labels_train6000 = labels_train[:6000]
    labels_train9000 = labels_train[:9000]
    labels_train12000 = labels_train[:12000]
    labels_train15000 = labels_train[:15000]
    labels_train16800 = labels_train
    
    model = KNeighborsClassifier(n_neighbors=2)
    # data_training = [data_train3000, data_train6000, data_train9000, data_train12000, data_train15000, data_train16800]
    # labels_training = [labels_train3000,labels_train6000,labels_train9000,labels_train12000,labels_train15000,labels_train16800]
    model_fit = timeit.timeit(lambda:model.fit(data_train3000, labels_train3000),number=1)
    model_fit1 = timeit.timeit(lambda:model.fit(data_train6000, labels_train6000),number=1)
    model_fit2 = timeit.timeit(lambda:model.fit(data_train9000, labels_train9000),number=1)
    model_fit3 = timeit.timeit(lambda:model.fit(data_train12000, labels_train12000),number=1)
    model_fit4 = timeit.timeit(lambda:model.fit(data_train15000, labels_train15000),number=1)
    model_fit5 = timeit.timeit(lambda:model.fit(data_train16800, labels_train16800),number=1)
    
    
    arrayx = [3000,6000,9000,12000,15000,16800]
    arrayy = [model_fit,model_fit1,model_fit2,model_fit3,model_fit4,model_fit5]
    plt.plot(arrayx, arrayy, 'r--')
    plt.show()
    array = [50,150,250,350,450,550,650,750]
    listedpca = [PCA(n_components=n) for n in array]
    model = KNeighborsClassifier(n_neighbors=2)
    datatrain_principalcomponents = [pacman.fit_transform(data_train) for pacman in listedpca]
    # datatest_principalcomponents = [pacman.fit_transform(data_test) for pacman in listedpca]
    timed = [timeit.timeit(lambda: model.fit(i, labels_train),number=1) for i in datatrain_principalcomponents]
    plt.plot(array, timed)
    plt.show()
    # The most affect for trend is when PCA is increased from 50 to 600 plus, where time complexity jumps.
    # The increase in data linearly increases with time.
#threeD(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test)
def threee(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test):
    model = KNeighborsClassifier(n_neighbors=2)
    data_train9000 = data_train[:9000]
    labels_train9000 = labels_train[:9000]
    pca = PCA(n_components=550)
    # K = 2, Samples = 9000, pca = 550
    principalComponents = pca.fit_transform(data_train9000)
    principalComponents2 = pca.fit_transform(data_test)
    
    model1 = model.fit(principalComponents, labels_train9000)
    print(accuracy_score(labels_train9000,model1.predict(principalComponents)), "Train Accuracy")
    
    model2 = model.fit(principalComponents2, labels_test)
    print(accuracy_score(labels_test,model2.predict(principalComponents2)), "Test Accuracy")
    #     0.9733333333333334 Train Accuracy
    # 0.9683333333333334 Test Accuracy
    # This model is 1% less accurate than the most accurate model when time wasn't a factor. I will be using this model from now on.
#threee(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test)
def threef(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test):
    pca = IncrementalPCA(n_components=10)
    plott = pca.inverse_transform(mnist_data)
    plt.imshow(plott,cmap = plt.cm.gray)
    arr = [i+1 for i in range(21000)]
    plott = pd.DataFrame(plott)
    for i in range(10):
        plt.plot(arr, plott[i])
        plt.show()
        plt.clf()
#threef(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test)
def threeff(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test):
    pca2 = IncrementalPCA(n_components=10)
    plott = pca2.inverse_transform(pca2.fit_transform(mnist_data))
    plt.figure(figsize=[12,8])
    plt.imshow(plott,cmap = plt.cm.gray)
    plt.show()
    
threeff(mnist_data, mnist_labels,data_train, data_test, labels_train, labels_test)