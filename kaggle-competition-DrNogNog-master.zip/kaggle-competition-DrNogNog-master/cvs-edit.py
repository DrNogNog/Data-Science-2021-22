
import pandas as pd

test_df = pd.read_csv("./data/X_train.csv")
test_df = test_df.sort_values(by='Score', ascending=True)
test_df.dropna()
test_df.to_csv("./data/NewFileX1.csv", index=False)
