import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import matplotlib.pyplot as plt
#nltk.download('stopwords')
#trainingSet = pd.read_csv("./data/train.csv")
testingSet = pd.read_csv("./data/test.csv")
trainingSet = pd.read_csv("./data/X_train - Testing.csv")
# print("train.csv shape is ", trainingSet.shape)
# print("test.csv shape is ", testingSet.shape)

# print()

# print(trainingSet.head())
# print()
# print(testingSet.head())

# print()
#print(trainingSet)
# print(trainingSet.describe())
#print(trainingSet['UserId'].value_counts(normalize=True))
value_counts = trainingSet['UserId'].value_counts(normalize=True).to_frame()
print(value_counts['UserId'])

#df_value_counts = trainingSet.FrequencyUsers.value_counts().rename_axis('FrequencyUsers').reset_index(name='FrequencyUsers')
#trainingSet['FrequencyUsers'] = trainingSet['UserId'].value_counts().to_frame() 

trainingSet.head(10)
value_counts.to_csv("./data/X_train - Testing2.csv", index=False)

# trainingSet['ProductId'].value_counts().plot(kind='bar', legend=True, alpha=.5)
# plt.title("Count of Scores")
# plt.show()




# trainingSet['ProductId'].value_counts().nlargest(25).plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 most Rated Products")
# plt.show()

# trainingSet['ProductID'].value_counts().nsmallest(25).plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 least Rated Products")
# plt.show()

# trainingSet['UserID'].value_counts().nlargest(25).plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 Reviewers")
# plt.show()

# trainingSet['UserID'].value_counts().nsmallest(25).plot(kind='bar', legend=True, alpha=.5)
# plt.title("Lowest 25  Reviewers")
# plt.show()
#-----------------------------------------------BREAKER---------------------------------------------
# trainingSet[['Score','HelpfulnessNumerator']].groupby('Score').mean().plot(kind='bar', legend=True, alpha=.5)
# plt.title("Mean Helpfulness Numerator per Score")
# plt.show()

# trainingSet[['Score','ProductID']].groupby('ProductID').mean().nlargest(25, 'Score').plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 bestRated Products")
# plt.show()

# trainingSet[['Score','ProductID']].groupby('ProductID').mean().nsmallest(25, 'Score').plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 worst Rated Products")
# plt.show()

# trainingSet[['Score','UserID']].groupby('UserID').mean().nlargest(25,'Score').plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 kindest Reviewers")
# plt.show()

# trainingSet[['Score','UserID']].groupby('UserID').mean().nsmallest(25,'Score').plot(kind='bar', legend=True, alpha=.5)
# plt.title("Top 25 harshest Reviewers")
# plt.show()

## trainingSet['ProductID'].isin(trainingSet['ProductId'].value_counts().nlargest(25).index.tolist())
# plt.title("Mean of top 25 most rated Products")
# plt.show()

## trainingSet['ProductID'].isin(trainingSet['ProductId'].value_counts().nsmallest(25).index.tolist())
# plt.title("Mean of top 25 least rated Products")
# plt.show()

## trainingSet['UserID'].isin(trainingSet['UserId'].value_counts().nlargest(25).index.tolist())
# plt.title("Mean of top 25 Reviewers")
# plt.show()

## trainingSet['UserID'].isin(trainingSet['UserId'].value_counts().nlargest(25).index.tolist())
# plt.title("Mean of lowest 25 Reviewers")
# plt.show()

# trainingSet['Date'] = pd.to_datetime(trainingSet['Time'], unit='s')
# trainingSet['Month'] = trainingSet['Date'].dt.month
# trainingSet['Year'] = trainingSet['Date'].dt.year
# trainingSet['Hour'] = trainingSet['Date'].dt.hour

