import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix
from sklearn.naive_bayes import MultinomialNB
import os
# from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import OneHotEncoder
from imblearn.over_sampling import RandomOverSampler
import scipy
from scipy.sparse import hstack
import nltk
nltk.download('wordnet')
nltk.download('stopwords')
from nltk.corpus import stopwords
import gensim
from gensim.models import Word2Vec
import nltk
nltk.download("wordnet")
nltk.download("punkt")
from nltk.stem import WordNetLemmatizer
lemmatizer=WordNetLemmatizer()
from nltk.corpus import stopwords

stopwords_set = set(stopwords.words("English"))
# Load files into DataFrames
X_train = pd.read_csv("./data/X_train.csv")
X_submission = pd.read_csv("./data/X_submission.csv")
sample = pd.read_csv('./data/sample.csv')

# topWords = []
# for i in range(1,6):
#     words = pd.Series(word_tokenize(' '.join(X_train.where(X_train['Score'] == float(i))['Text'].dropna()).lower())).value_counts()
#     topWordsForScore = words.where(~words.index.isin(stopwords.words()))
#     topWords.append(topWordsForScore)
# for i in range(len(topWords)):
#     allExcepti = topWords[:i] + topWords[i+1:]
#     flattened = pd.concat(allExcepti)
#     topWords[i] = topWords[i].where(~topWords[i].index.isin(flattened.nlargest(100).index.tolist()))
#     print("Top 100 words sort of unique toScore = ", i + 1)
#     print(topWords[i].nlargest(100).index.tolist())

# X_train = X_train.sample(n = 1000)
# Split training set into training and testing set
# X_train, X_test, Y_train, Y_test = train_test_split(
#         X_train['Text'],
#         X_train['Score'],
#         test_size=1/4.0,
#         random_state=0
#     )
OHE = OneHotEncoder(sparse=True)
ID_fitter = OHE.fit(X_train[['ProductId', 'UserId']])
IDs = ID_fitter.transform(X_train[['ProductId', 'UserId']])

X_train['Text'].loc[X_train['Text'].isna()] = ''
X_train['Summary'].loc[X_train['Summary'].isna()] = ''


vv = TfidfVectorizer(input='content', analyzer='word', stop_words='english')
summaryv = TfidfVectorizer(input='content', analyzer='word', stop_words='english')

vfitter = vv.fit(X_train['Text'])
textmatrix = vfitter.transform(X_train['Text'])
summaryfitter = summaryv.fit(X_train['Summary'])
summarymatrix = summaryfitter.transform(X_train['Summary'])

numerical = scipy.sparse.csr_matrix(X_train[['HelpfulnessNumerator', 'HelpfulnessDenominator', 'Time']].values)
X = hstack([textmatrix, summarymatrix, numerical, IDs])
mask = X_train["Score"].isnull()

ind_test = mask.to_numpy().nonzero()[0]
ind_train = (~ mask).to_numpy().nonzero()[0]

X_train = scipy.sparse.csr_matrix(X)[ind_train]
test_X = scipy.sparse.csr_matrix(X)[ind_test]

Y_train = X_train['Score'].loc[X_train['Score'].isna() == False]
test_Y = X_train['Score'].loc[X_train['Score'].isna()]

Y_train = Y_train.reset_index()['Score']
test_Y = test_Y.reset_index()['Score']

ros = RandomOverSampler(random_state=42)
X_train, Y_train = ros.fit_resample(X_train, Y_train)

X_train, X_valid, y_train, y_valid = train_test_split(X_train, Y_train, test_size=0.2, random_state=42)

model = MultinomialNB()
model.fit(X_train, Y_train)

X_submission_processed = X_submission.drop(columns=['Id', 'ProductId', 'UserId', 'Text', 'Summary', 'Score'])
Y_test_predictions = model.predict(test_X)
X_submission['Score'] = model.predict(X_submission_processed)


# Evaluate your model on the testing set
print("RMSE on testing set = ", mean_squared_error(y_valid, Y_test_predictions))

# Plot a confusion matrix
cm = confusion_matrix(y_valid, Y_test_predictions, normalize='true')
sns.heatmap(cm, annot=True)
plt.title('Confusion matrix of the classifier')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# Create the submission file
submission = X_submission[['Id', 'Score']]
submission.to_csv("./data/submission.csv", index=False)

# # Evaluate your model on the testing set
# print("RMSE on testing set = ", mean_squared_error(Y_test, Y_test_predictions))

# submission = pd.DataFrame(sample)
# submission['Score'] = model.predict(test_X)
# submission.to_csv("./data/submission.csv", index=False)

