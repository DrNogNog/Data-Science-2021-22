import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix
from sklearn.naive_bayes import MultinomialNB
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix
from sklearn.naive_bayes import MultinomialNB
import os
from sklearn.feature_extraction.text import CountVectorizer
# from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import OneHotEncoder
from imblearn.over_sampling import RandomOverSampler
from sklearn.svm import SVC
from sklearn import metrics
import scipy
from scipy.sparse import hstack
import nltk
nltk.download('wordnet')
nltk.download('stopwords')
from nltk.corpus import stopwords
import gensim
from gensim.models import Word2Vec
import nltk
import numpy as np
nltk.download("wordnet")
nltk.download("punkt")
from nltk.stem import WordNetLemmatizer
lemmatizer=WordNetLemmatizer()
from nltk.corpus import stopwords
# Load files into DataFrames
train_df = pd.read_csv("./data/X_train.csv")
test_df = pd.read_csv("./data/NewFileTest.csv")
X_submission = pd.read_csv("./data/X_submission.csv")
# instatntiate the vectorizer


X_train = train_df['Text']
Y_train = train_df['Score']
X_test = test_df['Text']
Y_test = test_df['Score']
 
vector = TfidfVectorizer(stop_words="english").fit(X_train)
vector = vector.transform(X_train["Text"])
X_train = vector.fit_transform(X_train.replace(np.nan,""))
X_test = vector.transform(X_test)

model = MultinomialNB()
model.fit(X_train,Y_train)


X_submission_processed = X_submission.drop(columns=['Id', 'ProductId', 'UserId', 'Summary','HelpfulnessNumerator','HelpfulnessDenominator','Time'])
# Predict the score using the model
Y_test_predictions = model.predict(X_test)
X_submission_transformed = vector.transform(X_submission.Text)
X_submission['Score'] = model.predict(X_submission_transformed)
# Evaluate your model on the testing set
print("RMSE on testing set = ", mean_squared_error(Y_test, Y_test_predictions))

# Plot a confusion matrix
cm = confusion_matrix(Y_test, Y_test_predictions, normalize='true')
sns.heatmap(cm, annot=True)
plt.title('Confusion matrix of the classifier')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# Create the submission file
submission = X_submission[['Id', 'Score']]
submission.to_csv("./data/submission.csv", index=False)
